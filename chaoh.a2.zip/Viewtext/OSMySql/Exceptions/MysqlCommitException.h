//
//  MysqlCommitException.h
//  mysql_connector
//
//  Created by Karl Kraft on 2/23/10.
//  Copyright 2010 Karl Kraft. All rights reserved.
//


#import "MysqlException.h"

@interface MysqlCommitException : MysqlException {

}

@end
