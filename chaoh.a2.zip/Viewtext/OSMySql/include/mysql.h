#if defined(__LP64__) || defined(NS_BUILD_32_LIKE_64)
#include "mysql_64.h"
#else
#include "mysql_32.h"
#endif

