//
//  SearchBookViewController.h
//  Viewtext
//
//  Created by Chao Huang on 9/21/14.
//  Copyright (c) 2014 Clemson. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchBookViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic) NSInteger selectedBook;

@end
